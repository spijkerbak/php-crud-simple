<!DOCTYPE html>
<html lang="nl">

    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link type="text/css" rel="stylesheet" href="layout.css">
    </head>

    <body>

        <nav>
            <a href = ".">home</a>
            <a href = "create-tables.php">reset database</a>
            <a href = "customer-list.php">klanten</a>
        </nav>

        <h1>Home</h1>
        <p>CRUD-simple example V2.1</p>
        <p>Get sources on <a target="github" href="http://github.com/spijkerbak/php-crud-simple.git">Github</a>.
        <p><a href="../crud/">Another example available</a></p>

    </body>

</html>

